/* globals Chart:false, feather:false */

(function () {
  "use strict";

  feather.replace();

  $("#existingPatientTypeBtn").click(function () {
    $("#existingPatientID").removeClass("d-none");
    $("#selectPatientTypeBody").addClass("d-none");
    $("#selectPatientTypeBody").removeClass("d-flex");
    $("#patientFormBody").removeClass("d-none");
    $("#createFormFooter").removeClass("d-none");
  });

  $("#createPatientTypeBtn").click(function () {
    $("#selectPatientTypeBody").addClass("d-none");
    $("#selectPatientTypeBody").removeClass("d-flex");
    $("#patientFormBody").removeClass("d-none");
    $("#createFormFooter").removeClass("d-none");
  });

  $("#createFormFooter Button").click(function (params) {
    $("#patientFormBody").addClass("d-none");
    $("#patientFormBody").removeClass("d-flex");
    $("#patientCreatedConfirmationBody").removeClass("d-none");
    $("#createFormFooter").addClass("d-none");
    $("#createFormFooter").removeClass("d-flex");
  });

  $("#createAppointmentBtn").click(function () {
    $("#existingPatientID").addClass("d-none");
    $("#selectPatientTypeBody").removeClass("d-none");
    $("#selectPatientTypeBody").addClass("d-flex");
    $("#patientFormBody").addClass("d-none");
    $("#createFormFooter").addClass("d-none");
    $("#patientCreatedConfirmationBody").addClass("d-none");
  });
})();
