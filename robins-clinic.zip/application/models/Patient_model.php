<?php  

    class Patient_model extends CI_Model  {  
        function __construct() {  
            // Call the Model constructor  
            parent::__construct();  
        }  

        //we will use the select function  
        public function select() {  
            //data is retrive from this query  
            $query = $this->db->get('tbl_patients');  
            return $query;  
        }  

        public function insert_patient() {    
            $data = array(
                        'patient_id' => $this->input->post('patient_id'),
                        'patient_name' => $this->input->post('patient_name'),
                        'mobile_number' => $this->input->post('mobile_number'),
                        'address' => $this->input->post('address'),
                        'doctor_id' => $this->input->post('doctor_id'),
                        'appointment_date_time' => $this->input->post('appointment_date_time')
                        );
            // users is the name of the db table you are inserting in
            return $this->db->insert('tbl_patients', $data);
        }   
    }  
?>