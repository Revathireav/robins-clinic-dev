<?php

  class Dashboard extends CI_Controller{

    function __construct(){
        parent::__construct();
        if($this->session->userdata('logged_in') !== TRUE){
            redirect('login');
        }
        $this->load->model('login_model');
        $this->load->model('Doctor_model');
        $this->load->model('Patient_model');
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
    }

    function index(){
        //Allowing akses to admin only
        if($this->session->userdata('level')==='1'){
            $this->load->view('layout/header.php');
            $data['doctors']=$this->Doctor_model->select(); 
            $data['patients']=$this->Patient_model->select();  
            $this->load->view('admin/index.php', $data);
        }else{
            echo "Access Denied";
        }
    }

    function staff(){
        //Allowing akses to staff only
        if($this->session->userdata('level')==='2'){
            $this->load->view('dashboard_view');
        }else{
            echo "Access Denied";
        }
    }

    function author(){
        //Allowing akses to author only
        if($this->session->userdata('level')==='3'){
            $this->load->view('dashboard_view');
        }else{
            echo "Access Denied";
        }
    }

    public function create(){
        $data['patients']=$this->Doctor_model->select(); 
        $this->form_validation->set_rules('patient_name', 'Patient Name', 'required');
        $this->form_validation->set_rules('mobile_number', 'Mobile Number', 'required', array('required' => 'You must provide a %s.') );
        $this->form_validation->set_rules('address', 'Address', 'required');
        $this->form_validation->set_rules('doctor_id', 'Doctor Id', 'required');
        $this->form_validation->set_rules('appointment_date_time','Appointment Date Time','required');
        if ($this->form_validation->run() === FALSE) {
            $this->load->view('admin/index.php', $data);
        } else {
            $this->Patient_model->insert_patient();
            redirect('admin/dashboard');
        }
    }

    public function getpatientrecord($id){
        $result = $this->db->where("id",$id)->get("tbl_patients")->result();
        echo json_encode($result);
    }

  }
