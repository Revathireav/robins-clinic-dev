<?php
class Login extends CI_Controller{
  function __construct(){
    parent::__construct();
    $this->load->model('login_model');
  }

  function index(){
    $this->load->view('login_view');
  }

  function auth(){
    
    $email    = $this->input->post('email',TRUE);
    $password = md5($this->input->post('password',TRUE));
    $user_role    = $this->input->post('user_role',TRUE);
   
    $validate = $this->login_model->validate($email,$password);
    if($validate->num_rows() > 0){
        $data  = $validate->row_array();
        $name  = $data['user_name'];
        $email = $data['user_email'];
        $level = $data['user_level'];
        $sesdata = array(
            'username'  => $name,
            'email'     => $email,
            'level'     => $level,
            'logged_in' => TRUE
        );
        $this->session->set_userdata($sesdata);
       /*  echo "<pre>";
    print_r($user_role);
    exit();*/
        // access login for admin
        if($user_role === '1' ){
            redirect('admin/dashboard');

        // access login for staff
        }elseif($user_role === '2'){
            redirect('admin/dashboard/staff');

        // access login for author
        }else{
            redirect('admin/dashboard/author');
        }
    }else{
        echo $this->session->set_flashdata('msg','Username or Password is Wrong');
        redirect('login');
    }
  }

  function logout(){
      $this->session->sess_destroy();
      redirect('login');
  }

}
