<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/jquery.datetimepicker.min.css');?>"/>
<div class="modal fade" id="createModal" tabindex="-1" aria-labelledby="createModalLabel" aria-hidden="true" >
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="<?php echo site_url('admin/dashboard/create');?>">
                <div class="modal-header border-0">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close" >
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                <!-- Existing/New Patient type selection Heading -->
                <div id="selectPatientTypeHead">
                    <h3 class="modal-title text-center" id="createModalLabel"> Select Patient Type </h3>
                </div>
                <div id="createPatientHead" class="d-none">
                    <h3 class="modal-title text-center" id="createModalLabel"> Create New Appointment </h3>
                </div>
                <div id="patientCreateConfirmationHead" class="d-none">
                    <h3 class="modal-title text-center" id="createModalLabel"> Appointment Confirmed </h3>
                </div>            
                <!-- END - Existing/New Patient type selection Heading -->
                <!-- Existing/New Patient type selection for Appointments -->
                <div id="selectPatientTypeBody" class="d-flex flex-column justify-content-center mt-3" >
                    <button id="existingPatientTypeBtn" type="button" class="btn btn-light mx-auto mt-1 mb-3">
                        <div class="mx-auto p-3 bg-dark rounded-circle" style="height: 100px; width: 100px" >
                            <span data-feather="user" style="color: #fff; height: 100%; width: 100%" ></span>
                        </div>
                        <h6 class="mt-2 text-muted">Existing Patient</h6>
                    </button>
                    <button id="createPatientTypeBtn" type="button" class="btn btn-light mx-auto mt-1 mb-3">
                        <div class="mx-auto pl-4 pr-3 bg-dark rounded-circle" style="height: 100px; width: 100px" >
                            <span data-feather="user-plus" style="color: #fff; height: 100%; width: 100%" ></span>
                        </div>
                        <h6 class="mt-2 text-muted">New Patient</h6>
                    </button>
                </div>
                    <div id="patientFormBody" class="d-none flex-column justify-content-center mt-3 px-5" >
                      <!-- add to include d-flex -->
                      <div id="existingPatientID" class="form-group d-none">
                          <label for="exampleFormControlSelect1">Patient ID</label>
                          <select class="form-control" id="exampleFormControlSelect1" name="select_patient_id">
                              <?php  
                            foreach ($patients->result() as $pid) { ?>
                              <option value="<?php echo $pid->id; ?>"><?php echo $pid->id; ?></option>
                            <?php }  
                          ?>  
                          </select>
                      </div>
                      <div class="form-group">
                        <label for="exampleFormControlInput1">Patient Name</label>
                        <input type="text" class="form-control patient_name" name="patient_name" id="exampleFormControlInput1">
                      </div>
                      <div class="form-group">
                        <label for="exampleFormControlInput1">Mobile Number</label>
                        <input type="tel" class="form-control mobile_number"  name="mobile_number" id="exampleFormControlInput1">
                        <span id="errmsg" style="color: red"></span>
                      </div>
                      <div class="form-group">
                        <label for="exampleFormControlInput1">Address</label>
                        <input type="text" class="form-control address" name="address" id="exampleFormControlInput1">
                      </div>
                      <div class="form-group">
                        <label for="exampleFormControlInput1">Doctor Name</label>
                        <select class="form-control doctor_id" name="doctor_id">
                          <?php  
                            foreach ($doctors->result() as $row) { ?>
                              <option value="<?php echo $row->id; ?>"><?php echo $row->name; ?></option>
                            <?php }  
                          ?>  
                        </select>
                      </div>
                      <div class="form-group">
                        <label for="exampleFormControlInput1">Appointment Date & Time</label>
                        <input type="datetime" name="appointment_date_time"  class="form-control datetimepicker appointment_date_time" id="exampleFormControlInput1" placeholder="">
                      </div>
                    </div>
                    <div id="patientCreatedConfirmationBody" class="d-none flex-column justify-content-center mt-3 mb-3 px-5">
                        <!-- add to include d-flex -->
                        <div class="mx-auto p-3 bg-dark rounded-circle" style="height: 100px; width: 100px">
                            <span data-feather="check" style="color: #fff; height: 100%; width: 100%" ></span>
                        </div>
                        <h4 class="mt-3 mb-5 text-center">Appointment has been confirmed. SMS will be sent to the patient mobile number.</h4>
                    </div>
                <!-- END - Existing/New Patient type selection for Appointments -->
                </div>
                <div id="createFormFooter" class="modal-footer px-5 d-none">
                  <input type="hidden" value="<?php echo uniqid(); ?>" name="patient_id" />
                  <button type="submit" class="btn btn-dark">Save changes</button>
                </div> 
            </form>
        </div>
    </div>
</div>   

<!-- Edit Appointments Modal -->
    <div
      class="modal fade"
      id="editAppointmentsModal"
      tabindex="-1"
      aria-labelledby="editAppointmentsModalLabel"
      aria-hidden="true"
    >
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header border-0">
            <button
              type="button"
              class="close"
              data-dismiss="modal"
              aria-label="Close"
            >
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            
            <!-- Edit Appointment Heading -->
            <div id="editAppointmentHead">
              <h3 class="modal-title text-center" id="editAppointmentsModalLabel">
                Edit Appointment
              </h5>
            </div>
            <!-- END - Edit Appointment Heading -->

            <!-- Edit Appointment Confirmed Heading -->
            <div id="appointmentEditConfirmationHead" class="d-none">
              <h3 class="modal-title text-center" id="editAppointmentsModalLabel1">
                Appointment Updated
              </h5>
            </div>            
            <!-- END - Edit Appointment Confirmed Heading -->

            <!-- Edit form for Appointments -->
            <div
              id="editAppointmentsFormBody"
              class="d-flex flex-column justify-content-center mt-3 px-5"
            >
            <form>
              <div class="form-group">
                <label for="exampleFormControlInput1">Patient Name</label>
                <input type="text" class="form-control" id="exampleFormControlInput1">
              </div>
              <div class="form-group">
                <label for="exampleFormControlInput1">Mobile Number</label>
                <input type="tel" class="form-control" id="exampleFormControlInput1">
              </div>
              <div class="form-group">
                <label for="exampleFormControlInput1">Address</label>
                <input type="text" class="form-control" id="exampleFormControlInput1">
              </div>
              <div class="form-group">
                <label for="exampleFormControlInput1">Doctor Name</label>
                <input type="text" class="form-control" id="exampleFormControlInput1">
              </div>
              <div class="form-group">
                <label for="exampleFormControlInput1">Appointment Date & Time</label>
                <input type="datetime" class="form-control" id="exampleFormControlInput1" placeholder="">
              </div>
            </form>
            </div>
            <!-- END - Edit form for Appointments -->

            <!-- Confirmation message for Appointments -->
            <div
            id="appointmentEditedConfirmationBody"
            class="d-none flex-column justify-content-center mt-3 mb-3 px-5">
            <div class="mx-auto p-3 bg-dark rounded-circle" style="height: 100px; width: 100px">
                    <span
                      data-feather="check"
                      style="color: #fff; height: 100%; width: 100%"
                    ></span>
                  </div>
            <h4 class="mt-3 mb-5 text-center">Appointment has been updated. SMS will be sent to the patient mobile number with new appointment details.</h4>
            </div>
            <!-- END - Confirmation message for Appointments -->

          </div>
           <div id="editAppointmentFormFooter" class="modal-footer px-5">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
            <button type="button" class="btn btn-dark">Save changes</button>
          </div> 
        </div>
      </div>
    </div>
    <!-- End Edit Appointments Modal -->

    <!-- Delete Appointments Modal -->
    <div
      class="modal fade"
      id="deleteAppointmentsModal"
      tabindex="-1"
      aria-labelledby="deleteAppointmentsModalLabel"
      aria-hidden="true"
    >
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header border-0">
            <button
              type="button"
              class="close"
              data-dismiss="modal"
              aria-label="Close"
            >
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            
            <!-- Delete Appointment Heading -->
            <div id="deleteAppointmentHead">
              <h3 class="modal-title text-center" id="deleteAppointmentsModalLabel">
                Remove Appointment
              </h5>
            </div>
            <!-- END - Delete Appointment Heading -->

            <!-- Confirmation message for deleting Appointment -->
            <div
            id="deleteAppointmentConfirmationBody"
            class="d-flex flex-column justify-content-center mt-3 mb-3 px-5">
            <div class="mx-auto p-3 bg-dark rounded-circle" style="height: 100px; width: 100px">
                    <span
                      data-feather="help-circle"
                      style="color: #fff; height: 100%; width: 100%"
                    ></span>
                  </div>
            <h5 class="mt-3 mb-3 text-center">Are you sure you want to delete this appointment?</h5>
            </div>
            <!-- END - Confirmation message for deleting Appointment -->

          </div>
           <div id="deleteAppointmentFormFooter" class="modal-footer px-5">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
            <button type="button" class="btn btn-dark" data-dismiss="modal">Yes</button>
          </div> 
        </div>
      </div>
    </div>
    <!-- End Delete Appointments Modal -->
        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-md-4">
          <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom" >
            <h1 class="h2">Appointments</h1>
            <div class="input-group mb-3 mb-md-0 search-bar">
              <div class="input-group-prepend">
                <span class="input-group-text bg-white search-icon" data-feather="search" style="height: 100%; width: 100%" ></span>
              </div>
              <input class="form-control form-control-light" type="text" id="search_patient" placeholder="Search By Patient ID & Patient Name" aria-label="Search" />
            </div>
          </div>
          <div class="table-responsive">
            <table class="table table-dark table-hover" id="appointment_table">
              <thead class="thead-light">
              <tr>
              <th>#</th>
              <th>Patient Name</th>
              <th>Contact Number</th>
              <th>Doctor Name</th>
              <th>Appointment Date & Time</th>
              <th>Action</th>
              </tr>
              </thead>
              <tbody>
                <?php  
                  foreach ($patients->result() as $row) { ?>
                    <tr>
                      <td><?php echo $row->id; ?></td>
                      <td><?php echo $row->patient_name; ?></td>
                      <td><?php echo $row->mobile_number; ?></td>
                        <?php 
                          $doctor_id = $row->doctor_id; 
                          $sql ="SELECT * FROM tbl_doctors WHERE id='". $doctor_id ."'";
                          $query = $this->db->query($sql);
                          if ($query->num_rows() > 0) {
                            foreach ($query->result() as $doctor) { ?>
                              <td><?php echo $doctor->name; ?></td>
                            <?php }
                          }
                        ?>
                      <td><?php echo $row->appointment_date_time; ?></td>
                      <td>
                        <a class="text-light editdata" id="edit-<?php echo $row->id; ?>" data-toggle="modal" data-target="#editAppointmentsModal">
                          <span data-feather="edit"></span>
                         
                        </a>
                        <a class="text-light" data-toggle="modal" data-target="#deleteAppointmentsModal">
                          <span data-feather="x-circle"></span>
                        </a>
                      </td>
                    </tr>
                  <?php } 
                ?>
              </tbody>
            </table>
          </div>
          <div class="fixed-create-object fixed-bottom mx-auto my-3 rounded-circle shadow" >
            <button id="createAppointmentBtn" type="button" class="btn btn-dark rounded-circle shadow-lg" data-toggle="modal" data-target="#createModal" >
              <span data-feather="plus" style="height: 32px; width: 32px" ></span>
            </button>
          </div>
        </main>
      </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous" ></script>
    <script src="<?php echo base_url('assets/src/bootstrap.bundle.min.js');?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/feather-icons/4.9.0/feather.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.3/Chart.min.js"></script>
    <script src="<?php echo base_url('assets/src/dashboard.js');?>"></script>
 <script src="<?php echo base_url('assets/js/jquery.min.js');?>"></script>


     <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
  <script src="<?php echo base_url('assets/js/jquery.datetimepicker.js');?>"></script>

    <script>
$(document).ready(function(){
  $("#search_patient").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#appointment_table tbody tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

//mobile number validation

$(document).ready(function () {

  //called when key is pressed in textbox
  $(".mobile_number").keypress(function (e) {
     //if the letter is not digit then display error and don't type anything
     if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
        //display error message
        $("#errmsg").html("Digits Only").show().fadeOut("slow");
        return false;
    }

    if(this.value.length >= 12) {
      alert('maximum of 12 characters.');
    }
     if(e.which === 32 && !this.value.length)
          e.preventDefault();
   });
});

$(document).ready(function(){
  //Inline DateTimePicker Example
     $('.datetimepicker').datetimepicker();
})

</script>
<script type="text/javascript">
  $(document).ready(function() {
   // $('.search-icon').css('width','102%');
    $('select[name="select_patient_id"]').on('change', function() {
      
      var patient_id = $(this).val();
      if(patient_id) {
        $.ajax({

          url: '<?php echo site_url('admin/dashboard/getpatientrecord');?>/'+patient_id,
          type: "GET",
          dataType: "json",
          success:function(data) {
            $.each(data, function(key, value) {
              console.log(value.patient_name)
             $('.patient_name').val(value.patient_name);
             $('.mobile_number').val(value.mobile_number);
             $('.address').val(value.address);
             $('.doctor_id').val(value.doctor_id);
             $('.appointment_date_time').val(value.appointment_date_time);
            });
          }
        });
      }else{
        alert("failed")
      }
    });
  });
</script>

  </body>
</html>
