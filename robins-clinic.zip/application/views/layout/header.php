<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />
    <meta name="description" content="" />
    <title>Robin's Clinic Dashboard</title>

    <!-- Bootstrap core CSS -->
     <link href="<?php echo base_url('assets/css/bootstrap.min.css');?>" rel="stylesheet" />
    <link href="<?php echo base_url('assets/css/dashboard.css');?>" rel="stylesheet" />

    <!-- Custom styles for this template -->
  </head>
  <body>
    
    <nav class="navbar navbar-dark sticky-top flex-md-nowrap p-0">
      <span class="navbar-brand bg-dark col-md-3 col-lg-2 mr-0 px-3"
        >Robin's Clinic</span
      >
      <button
        class="navbar-toggler position-absolute d-md-none collapsed"
        type="button"
        data-toggle="collapse"
        data-target="#sidebarMenu"
        aria-controls="sidebarMenu"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <span class="navbar-toggler-icon"></span>
      </button>
    </nav>

    <div class="container-fluid">
      <div class="row">
        <nav
          id="sidebarMenu"
          class="col-md-3 col-lg-2 d-md-block bg-dark sidebar collapse"
        >
          <div class="sidebar-sticky pt-3">
            <!-- User Image section -->
            <div>
              <div
                class="mx-auto mt-3 mb-1 pl-4 pr-3 rounded-circle bg-light"
                style="height: 100px; width: 100px"
              >
                <span
                  data-feather="user-check"
                  style="height: 100%; width: 100%"
                ></span>
              </div>
            </div>
            <h6
              class="sidebar-heading d-flex justify-content-center flex-column align-items-center px-3 mt-3 mb-4 text-muted"
            >
              <div>User Type</div>
              <div id="userType">Admin</div>
            </h6>
            <!-- END User Image section -->

            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="calendar"></span>
                  Appointments
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="users"></span>
                  Patients
                </a>
              </li>
            </ul>

            <!-- <ul class="nav flex-column mb-2">
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="file-text"></span>
                  Current month
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="file-text"></span>
                  Last quarter
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="file-text"></span>
                  Social engagement
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="file-text"></span>
                  Year-end sale
                </a>
              </li>
            </ul> -->
            <!-- <div
            class="fixed-create-object fixed-bottom mx-auto my-3 rounded-circle shadow"
          >
            <button
              type="button"
              class="btn btn-dark rounded-circle shadow-lg"
              data-toggle="modal"
              data-target="#createModal"
            >
              <span
                data-feather="plus"
                style="height: 35px; width: 35px"
              ></span>
            </button>
          </div> -->
            <div
              class="fixed-log-out fixed-bottom mx-auto my-3 rounded-circle shadow"
            >
              <a
                id="logoutBtn"
                href="./index.html"
                class="btn btn-light rounded-circle shadow-lg"
              >
                <span
                  data-feather="log-out"
                  style="height: 32px; width: 32px"
                ></span>
              </a>
            </div>
          </div>
        </nav>