<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />
    <meta name="description" content="" />
    <title>Robin's Clinic Dashboard</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo base_url('assets/css/bootstrap.min.css');?>" rel="stylesheet" />
   <!--  <link href="css/bootstrap.min.css" rel="stylesheet" /> -->

    <!-- Custom styles for this template -->
    <link href="<?php echo base_url('assets/css/dashboard.css');?>" rel="stylesheet" />
    <!-- <link href="css/dashboard.css" rel="stylesheet" /> -->
  </head>
  <body>
    <!-- Modal -->
    <div
      class="modal fade"
      id="createModal"
      tabindex="-1"
      aria-labelledby="createModalLabel"
      aria-hidden="true"
    >
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header border-0">
            <h5 class="modal-title" id="createModalLabel">
              Select Patient Type
            </h5>
            <button
              type="button"
              class="close"
              data-dismiss="modal"
              aria-label="Close"
            >
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <div class="">
              <div
                class="mx-auto mt-3 mb-3 pl-3 pr-3 rounded-circle bg-dark"
                style="height: 100px; width: 100px"
              >
                <span
                  data-feather="user"
                  style="color: #fff; height: 100%; width: 100%"
                ></span>
              </div>
              <h6
                class="d-flex justify-content-center flex-column align-items-center px-3 mt-3 mb-4 text-muted"
              >
                <div>Existing Patient</div>
              </h6>
              <div
                class="mx-auto mt-5 mb-3 pl-4 pr-3 rounded-circle bg-dark"
                style="height: 100px; width: 100px"
              >
                <span
                  data-feather="user-plus"
                  style="color: #fff; height: 100%; width: 100%"
                ></span>
              </div>
              <h6
                class="d-flex justify-content-center flex-column align-items-center px-3 mt-3 mb-4 text-muted"
              >
                <div>New Patient</div>
              </h6>
            </div>
          </div>
          <!-- <div class="modal-footer">
            <button
              type="button"
              class="btn btn-secondary"
              data-dismiss="modal"
            >
              Close
            </button>
            <button type="button" class="btn btn-dark">Save changes</button>
          </div> -->
        </div>
      </div>
    </div>
    <!-- End Modal -->
    <nav class="navbar navbar-dark sticky-top flex-md-nowrap p-0">
      <span class="navbar-brand bg-dark col-md-3 col-lg-2 mr-0 px-3"
        >Robin's Clinic</span
      >
      <button
        class="navbar-toggler position-absolute d-md-none collapsed"
        type="button"
        data-toggle="collapse"
        data-target="#sidebarMenu"
        aria-controls="sidebarMenu"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <span class="navbar-toggler-icon"></span>
      </button>
    </nav>


    <script
      src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
      integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
      crossorigin="anonymous"
    ></script>
    <script type="text/javascript" src="<?php echo base_url('assets/src/bootstrap.bundle.min.js');?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/feather-icons/4.9.0/feather.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.3/Chart.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url('assets/src/dashboard.js');?>"></script>
  </body>
</html>
