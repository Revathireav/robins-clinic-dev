<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />
    <meta name="description" content="" />
    <title>Robin's Clinic Dashboard</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo base_url('assets/css/bootstrap.min.css');?>" rel="stylesheet" />

    <!-- Custom styles for this template -->
    <link href="<?php echo base_url('assets/css/dashboard.css');?>" rel="stylesheet" />
  </head>
  <body>
    <!-- Modal -->
    <div
      class="modal fade"
      id="createModal"
      tabindex="-1"
      aria-labelledby="createModalLabel"
      aria-hidden="true"
    >
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header border-0">
            <h5 class="modal-title" id="createModalLabel">
              Select Patient Type
            </h5>
            <button
              type="button"
              class="close"
              data-dismiss="modal"
              aria-label="Close"
            >
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <div class="">
              <div
                class="mx-auto mt-3 mb-3 pl-3 pr-3 rounded-circle bg-dark"
                style="height: 100px; width: 100px"
              >
                <span
                  data-feather="user"
                  style="color: #fff; height: 100%; width: 100%"
                ></span>
              </div>
              <h6
                class="d-flex justify-content-center flex-column align-items-center px-3 mt-3 mb-4 text-muted"
              >
                <div>Existing Patient</div>
              </h6>
              <div
                class="mx-auto mt-5 mb-3 pl-4 pr-3 rounded-circle bg-dark"
                style="height: 100px; width: 100px"
              >
                <span
                  data-feather="user-plus"
                  style="color: #fff; height: 100%; width: 100%"
                ></span>
              </div>
              <h6
                class="d-flex justify-content-center flex-column align-items-center px-3 mt-3 mb-4 text-muted"
              >
                <div>New Patient</div>
              </h6>
            </div>
          </div>
          <!-- <div class="modal-footer">
            <button
              type="button"
              class="btn btn-secondary"
              data-dismiss="modal"
            >
              Close
            </button>
            <button type="button" class="btn btn-dark">Save changes</button>
          </div> -->
        </div>
      </div>
    </div>
    <!-- End Modal -->
    <nav class="navbar navbar-dark sticky-top flex-md-nowrap p-0">
      <span class="navbar-brand bg-dark col-md-3 col-lg-2 mr-0 px-3"
        >Robin's Clinic</span
      >
      <button
        class="navbar-toggler position-absolute d-md-none collapsed"
        type="button"
        data-toggle="collapse"
        data-target="#sidebarMenu"
        aria-controls="sidebarMenu"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <span class="navbar-toggler-icon"></span>
      </button>
    </nav>

    <div class="container-fluid">
      <div class="row">
        <nav
          id="sidebarMenu"
          class="col-md-3 col-lg-2 d-md-block bg-dark sidebar collapse"
        >
          <div class="sidebar-sticky pt-3">
            <!-- LOGO -->
            <div>
              <div
                class="mx-auto mt-3 mb-1 pl-4 pr-3 rounded-circle bg-light"
                style="height: 100px; width: 100px"
              >
                <span
                  data-feather="user-check"
                  style="height: 100%; width: 100%"
                ></span>
              </div>
            </div>

            <h6
              class="sidebar-heading d-flex justify-content-center flex-column align-items-center px-3 mt-3 mb-4 text-muted"
            >
              <div>User Type</div>
              <div id="userType">Admin</div>
            </h6>

            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="calendar"></span>
                  Appointments
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="users"></span>
                  Patients
                </a>
              </li>
            </ul>

            <!-- <ul class="nav flex-column mb-2">
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="file-text"></span>
                  Current month
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="file-text"></span>
                  Last quarter
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="file-text"></span>
                  Social engagement
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="file-text"></span>
                  Year-end sale
                </a>
              </li>
            </ul> -->
            <!-- <div
            class="fixed-create-object fixed-bottom mx-auto my-3 rounded-circle shadow"
          >
            <button
              type="button"
              class="btn btn-dark rounded-circle shadow-lg"
              data-toggle="modal"
              data-target="#createModal"
            >
              <span
                data-feather="plus"
                style="height: 35px; width: 35px"
              ></span>
            </button>
          </div> -->
            <div
              class="fixed-log-out fixed-bottom mx-auto my-3 rounded-circle shadow"
            >
              <a
                id="logoutBtn"
                href="./index.html"
                class="btn btn-light rounded-circle shadow-lg"
              >
                <span
                  data-feather="log-out"
                  style="height: 32px; width: 32px"
                ></span>
              </a>
            </div>
          </div>
        </nav>

        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-md-4">
          <div
            class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom"
          >
            <h1 class="h2">Appointments</h1>
            <div class="input-group mb-3 mb-md-0 search-bar">
              <div class="input-group-prepend">
                <span
                  class="input-group-text bg-white"
                  data-feather="search"
                  style="height: 100%; width: 100%"
                ></span>
              </div>
              <input
                class="form-control form-control-light"
                type="text"
                placeholder="Search By Patient ID & Patient Name"
                aria-label="Search"
              />
            </div>
            <!-- <div class="btn-toolbar mb-2 mb-md-0">
              
            </div> -->
          </div>

          <div class="table-responsive">
            <table class="table table-dark table-hover">
              <thead class="thead-light">
                <tr>
                  <th>#</th>
                  <th>Patient Name</th>
                  <th>Contact Number</th>
                  <th>Doctor Name</th>
                  <th>Appointment Date & Time</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>1,001</td>
                  <td>Lorem</td>
                  <td>ipsum</td>
                  <td>dolor</td>
                  <td>sit</td>
                  <td>
                    <a class="text-light">
                      <span data-feather="edit"></span>
                    </a>
                    <a class="text-light">
                      <span data-feather="x-circle"></span>
                    </a>
                  </td>
                </tr>
                <tr>
                  <td>1,002</td>
                  <td>amet</td>
                  <td>consectetur</td>
                  <td>adipiscing</td>
                  <td>elit</td>
                  <td>
                    <a class="text-light">
                      <span data-feather="edit"></span>
                    </a>
                    <a class="text-light">
                      <span data-feather="x-circle"></span>
                    </a>
                  </td>
                </tr>
                <tr>
                  <td>1,003</td>
                  <td>Integer</td>
                  <td>nec</td>
                  <td>odio</td>
                  <td>Praesent</td>
                  <td>
                    <a class="text-light">
                      <span data-feather="edit"></span>
                    </a>
                    <a class="text-light">
                      <span data-feather="x-circle"></span>
                    </a>
                  </td>
                </tr>
                <tr>
                  <td>1,003</td>
                  <td>libero</td>
                  <td>Sed</td>
                  <td>cursus</td>
                  <td>ante</td>
                  <td>
                    <a class="text-light">
                      <span data-feather="edit"></span>
                    </a>
                    <a class="text-light">
                      <span data-feather="x-circle"></span>
                    </a>
                  </td>
                </tr>
                <tr>
                  <td>1,004</td>
                  <td>dapibus</td>
                  <td>diam</td>
                  <td>Sed</td>
                  <td>nisi</td>
                  <td>
                    <a class="text-light">
                      <span data-feather="edit"></span>
                    </a>
                    <a class="text-light">
                      <span data-feather="x-circle"></span>
                    </a>
                  </td>
                </tr>
                <tr>
                  <td>1,005</td>
                  <td>Nulla</td>
                  <td>quis</td>
                  <td>sem</td>
                  <td>at</td>
                  <td>
                    <a class="text-light">
                      <span data-feather="edit"></span>
                    </a>
                    <a class="text-light">
                      <span data-feather="x-circle"></span>
                    </a>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
          <div
            class="fixed-create-object fixed-bottom mx-auto my-3 rounded-circle shadow"
          >
            <button
              type="button"
              class="btn btn-dark rounded-circle shadow-lg"
              data-toggle="modal"
              data-target="#createModal"
            >
              <span
                data-feather="plus"
                style="height: 32px; width: 32px"
              ></span>
            </button>
          </div>
        </main>
      </div>
    </div>
    <script
      src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
      integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
      crossorigin="anonymous"
    ></script>
    <script src="<?php echo base_url('assets/src/bootstrap.bundle.min.js');?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/feather-icons/4.9.0/feather.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.3/Chart.min.js"></script>
    <script src="<?php echo base_url('assets/src/dashboard.js');?>"></script>
  </body>
</html>
