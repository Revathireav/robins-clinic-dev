<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />

    <!-- Bootstrap CSS -->
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
      integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2"
      crossorigin="anonymous"
    />
    <link href="<?php echo base_url('assets/css/signin.css');?>" rel="stylesheet" />

    <title>Robin's Clinic Login</title>
  </head>
  <body>
    <body>
      <form class="form-signin" action="<?php echo site_url('login/auth');?>" method="post">
        <img
          class="mb-4"
          src="http://techkey.in/assets/img/logo/logo-2.png"
          alt=""
          style="background-color: #ccc"
        />
        <h1 class="h3 mb-3 font-weight-normal">Login</h1>
        <div class="form-group">
          <label for="exampleFormControlSelect1">User Type</label>
          <select class="form-control" id="exampleFormControlSelect1" name="user_role">
            <option value="1">Admin</option>
            <option value="2">Doctor</option>
            <option value="3">Front Office Executive</option>
          </select>
        </div>
        <div class="form-group">
          <label for="exampleInputEmail1">User Name</label>
          <input
            type="email"
            id="inputEmail"
            name="email"
            class="form-control"
            id="exampleInputEmail1"
            aria-describedby="emailHelp"
            required
            autofocus
          />

        </div>
        <div class="form-group">
          <label for="exampleInputPassword1">Password</label>
          <input
            type="password"
            class="form-control"
            name="password"
            id="exampleInputPassword1"
            required
          />
        </div>
        <button class="btn btn-lg btn-primary btn-block" type="submit">
          Login
        </button>
        <p class="mt-5 mb-3 text-muted">
          Copyright © 2020 All rights reserved | Designed by
          <a href="http://techkey.in" target="_blank">Techkey</a>
        </p>
      </form>
    </body>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script
      src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
      integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx"
      crossorigin="anonymous"
    ></script>
  </body>
</html>
